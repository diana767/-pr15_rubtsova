﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Remoting.Messaging;
using System.Web;

namespace RUBTSOVA15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool pr = true;

        public void Proverka(string ss)
        {
            for (int i = 0; i < ss.Length; i++)
            {
                if (!char.IsLetter(ss[i])) pr = false;
                if (ss.Length <= 0) pr = false;
            }
        }

        public void Prov(string s)
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (!char.IsDigit(s[i])) pr = false;
                if (s.Length != 6) pr = false;
            }
        }
        int i = 0;
        List<Address> list = new List<Address>();
        private void button1_Click(object sender, EventArgs e)
        {
            pr = true;
            try
            {
                if (new FileInfo("sd.txt").Length == 0)
                {
                    Address a1 = new Address();
                    a1.State = textBox1.Text;
                    a1.City = textBox2.Text;
                    a1.Street = textBox3.Text;
                    a1.Code = textBox4.Text;
                    Proverka(textBox1.Text);
                    Proverka(textBox2.Text);
                    Proverka(textBox3.Text);
                    Prov(textBox4.Text);
                    if (pr == true)
                    {
                        listBox1.Items.Add(a1.Getinfo());
                        list.Add(a1);
                        i++;
                        comboBox1.Items.Add(i);
                        StreamWriter sw = File.CreateText("sd.txt");
                        sw.WriteLine(a1.Getinfo());
                        sw.Close();

                    }
                    else
                    {
                        listBox1.Items.Add("Ваши данные некорректные");
                    }


                }
                else
                {
                    StreamReader sr = File.OpenText("sd.txt");
                    int j = 0;
                    list.Clear();
                    comboBox1.Items.Clear();
                    while (!sr.EndOfStream)
                    {
                        string[] line = sr.ReadLine().Split(',');
                        Proverka(line[0]);
                        Proverka(line[1]);
                        Proverka(line[2]);
                        Prov(line[3]);
                        if (pr == true)
                        {
                            Address a2 = new Address();
                            a2.State = line[0];
                            a2.City = line[1];
                            a2.Street = line[2];
                            a2.Code = line[3];
                            list.Add(a2);
                            listBox1.Items.Add(list[j].Getinfo());
                            j++;
                            comboBox1.Items.Add(j);
                        }
                    }
                    sr.Close();
                }


            }
            catch (FormatException)
            {
                MessageBox.Show("NO");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                list.RemoveAt(comboBox1.SelectedIndex);
                StreamWriter sw = File.CreateText("sd.txt");
                for (int i = 0; i < list.Count; i++)
                {
                    sw.WriteLine(list[i].Getinfo());
                }
                sw.Close();
            }
            catch (FormatException) { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                pr = true;
                Proverka(textBox1.Text);
                Proverka(textBox2.Text);
                Proverka(textBox3.Text);
                Prov(textBox4.Text);
                if (pr == true)
                {
                    list[comboBox1.SelectedIndex].Update(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
                    StreamWriter sw = File.CreateText("sd.txt");
                    for (int i = 0; i < list.Count; i++)
                    {
                        sw.WriteLine(list[i].Getinfo());
                    }
                    sw.Close();
                }
            }
            catch (FormatException) { }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Proverka(textBox1.Text);
                Proverka(textBox2.Text);
                Proverka(textBox3.Text);
                Prov(textBox4.Text);
                if (pr == true)
                {
                    Address a1 = new Address();
                    a1.State = textBox1.Text;
                    a1.City = textBox2.Text;
                    a1.Street = textBox3.Text;
                    a1.Code = textBox4.Text;
                    list.Add(a1);
                    listBox1.Items.Add(list[list.Count - 1].Getinfo());
                    StreamWriter sw = File.CreateText("sd.txt");
                    for (int i = 0; i < list.Count; i++)
                    {
                        sw.WriteLine(list[i].Getinfo());
                    }
                    sw.Close();


                }
            }
            catch (FormatException) { }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
   }

